package com.sashashtmv.game4in1.model;

public interface Item {
    //нужен, чтобы различать задачи от разделителей на экране(сепараторов)
    boolean isTask();
}
